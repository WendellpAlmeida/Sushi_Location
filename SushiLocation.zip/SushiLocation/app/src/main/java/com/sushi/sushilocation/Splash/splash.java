package com.sushi.sushilocation.Splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.sushi.sushilocation.FormLoggin.FormLoggin;
import com.sushi.sushilocation.R;

public class splash extends AppCompatActivity {

    String TAG = "Sushi Location";
     int tempoDeEspera = 1000 * 3 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();

        Log.d(TAG, "onCreate:Tela splash carregada");

        trocarTela();
    }

    private void trocarTela(){

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Log.d(TAG, "Esperando um tempo... ");
                Intent trocardeTela = new Intent(splash.this, FormLoggin.class);
                startActivity(trocardeTela);
                finish();
            }
        },tempoDeEspera);
    }
}