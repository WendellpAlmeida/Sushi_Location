package com.sushi.sushilocation.FormaCadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sushi.sushilocation.R;

public class FormCadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_cadastro);
        getSupportActionBar().hide();
    }
}